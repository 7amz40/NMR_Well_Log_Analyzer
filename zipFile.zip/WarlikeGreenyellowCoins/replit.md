# NMR Well Log Analyzer

## Project Overview
A React + Vite web application for quantitative interpretation of rock and fluid properties from NMR well log data.

## Architecture
- **Framework**: React 18 + Vite (port 5000)
- **Math rendering**: KaTeX (for engineering equations)
- **Styling**: Plain CSS modules per component

## Pages
- `/` — Home page (`src/components/HomePage.jsx`)

## Key Files
- `src/App.jsx` — Root component
- `src/components/HomePage.jsx` — Full home page
- `src/components/HomePage.css` — Home page styles
- `vite.config.js` — Dev server config (port 5000, host: true)
- `index.html` — HTML shell with KaTeX CDN CSS

## Features Implemented
- Sticky navigation bar with "Start Analysis" button
- Hero section with title, subtitle, and grid dot background
- About section
- Outputs section (Porosity, FFI, BFV, Permeability, RQI cards)
- Key Equations section with rendered KaTeX math (ϕ, k, RQI formulas)
- Features section (Upload, Depth Logs, Quantitative, Graph)
- CTA section with big "Start Analysis" button
- Footer

## Running
```
npm run dev
```
