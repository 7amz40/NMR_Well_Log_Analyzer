import { useNavigate } from 'react-router-dom'
import './HomePage.css'

export default function HomePage() {
  const navigate = useNavigate()
  const goToAnalysis = () => navigate('/analysis')

  return (
    <div className="nmr-root">
      <nav className="nmr-nav">
        <span className="nmr-nav-logo">NMR Analyzer</span>
        <div className="nmr-nav-links">
          <button className="nmr-nav-link" onClick={() => navigate('/about')}>About NMR</button>
          <button className="nmr-nav-btn" onClick={goToAnalysis}>Start Analysis</button>
        </div>
      </nav>

      <header className="nmr-hero">
        <div className="nmr-hero-badge">Nuclear Magnetic Resonance</div>
        <h1 className="nmr-title">NMR Well Log Analyzer</h1>
        <p className="nmr-subtitle">
          Extracting reservoir properties from NMR well log data
        </p>
        <div className="nmr-hero-divider" />
      </header>

      <section className="nmr-section nmr-about">
        <div className="nmr-container">
          <div className="nmr-section-label">About</div>
          <h2 className="nmr-section-title">What Is This Tool?</h2>
          <p className="nmr-about-text">
            This tool simulates Nuclear Magnetic Resonance (NMR) log interpretation by converting
            T₂ relaxation data into key reservoir properties using simplified engineering equations.
          </p>
        </div>
      </section>

      <section className="nmr-section nmr-outputs">
        <div className="nmr-container">
          <div className="nmr-section-label">Outputs</div>
          <h2 className="nmr-section-title">What the Tool Calculates</h2>
          <div className="nmr-outputs-grid">
            {[
              { symbol: 'ϕ', name: 'Porosity', desc: 'Total pore volume fraction of the rock' },
              { symbol: 'FFI', name: 'Free Fluid Index', desc: 'Fraction of fluid that can flow under gravity' },
              { symbol: 'BFV', name: 'Bound Fluid Volume', desc: 'Fluid held by capillary forces, immovable' },
              { symbol: 'k', name: 'Permeability', desc: 'Ability of rock to transmit fluid flow' },
              { symbol: 'RQI', name: 'Reservoir Quality Index', desc: 'Combined indicator of reservoir quality' },
            ].map((item) => (
              <div className="nmr-output-card" key={item.symbol}>
                <div className="nmr-output-symbol">{item.symbol}</div>
                <div className="nmr-output-name">{item.name}</div>
                <div className="nmr-output-desc">{item.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="nmr-section nmr-howitworks">
        <div className="nmr-container">
          <div className="nmr-section-label">Workflow</div>
          <h2 className="nmr-section-title">How the Analysis Works</h2>
          <div className="nmr-steps">
            {[
              { n: 1, text: 'Import NMR T₂ Distribution Data' },
              { n: 2, text: 'Analyze Signal Using NMR Principles' },
              { n: 3, text: 'Compute Reservoir Properties (φ, FFI, BFV, k)' },
              { n: 4, text: 'Visualize Results and Interpret Reservoir Behavior' },
            ].map((step) => (
              <div className="nmr-step" key={step.n}>
                <div className="nmr-step-number">{step.n}</div>
                <div className="nmr-step-text">{step.text}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="nmr-section nmr-cta">
        <div className="nmr-container nmr-cta-inner">
          <h2 className="nmr-cta-title">Ready to Analyze Your Well Log?</h2>
          <p className="nmr-cta-sub">Upload your T₂ data and get quantitative reservoir properties in seconds.</p>
          <button className="nmr-cta-btn" onClick={goToAnalysis}>Start Analysis</button>
        </div>
      </section>

      <footer className="nmr-footer">
        <div className="nmr-container">
          <span>NMR Well Log Analyzer</span>
          <div className="nmr-footer-credit">
            Department of Chemical and Petroleum Engineering &mdash; Sultan Qaboos University
          </div>
        </div>
      </footer>
    </div>
  )
}
