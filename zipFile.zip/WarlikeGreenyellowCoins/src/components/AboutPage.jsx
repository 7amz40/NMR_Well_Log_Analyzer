import { useNavigate } from 'react-router-dom'
import './AboutPage.css'

const sections = [
  {
    n: 1,
    title: 'What is NMR?',
    content: (
      <>
        <p>
          Nuclear Magnetic Resonance (NMR) is a technique used to analyze fluids within porous rocks
          by measuring the response of hydrogen nuclei in a magnetic field.
        </p>
        <p>
          Since hydrogen is present in both oil and water, NMR provides direct information about
          fluid distribution inside the reservoir.
        </p>
      </>
    ),
  },
  {
    n: 2,
    title: 'Working Principle',
    content: (
      <>
        <p>When a magnetic field is applied, hydrogen nuclei align with the field.</p>
        <ul>
          <li>A radio frequency (RF) pulse is applied, causing the nuclei to become excited.</li>
          <li>When the pulse is removed, the nuclei return to equilibrium and emit signals.</li>
          <li>These signals are analyzed to determine fluid properties.</li>
        </ul>
      </>
    ),
  },
  {
    n: 3,
    title: 'T₂ Relaxation & Pore Size',
    content: (
      <>
        <p>
          The T₂ relaxation time represents how quickly the signal decays. It is strongly related
          to pore size:
        </p>
        <div className="ab-pore-grid">
          <div className="ab-pore-card ab-pore-short">
            <span className="ab-pore-label">Short T₂</span>
            <span className="ab-pore-arrow">→</span>
            <span>Small pores</span>
            <span className="ab-pore-arrow">→</span>
            <span className="ab-pore-tag ab-bound">Bound Fluids</span>
          </div>
          <div className="ab-pore-card ab-pore-long">
            <span className="ab-pore-label">Long T₂</span>
            <span className="ab-pore-arrow">→</span>
            <span>Large pores</span>
            <span className="ab-pore-arrow">→</span>
            <span className="ab-pore-tag ab-free">Movable Fluids</span>
          </div>
        </div>
        <p>This relationship allows NMR to characterize pore structure.</p>
      </>
    ),
  },
  {
    n: 4,
    title: 'T₂ Distribution',
    content: (
      <>
        <p>
          The NMR measurement produces a T₂ distribution curve. Each point on the curve has an
          amplitude <em>Aᵢ</em>, which represents the volume of fluid in a specific pore size range.
        </p>
        <p>
          The total area under the curve represents the total fluid content in the rock.
        </p>
      </>
    ),
  },
  {
    n: 5,
    title: 'Porosity Equation',
    content: (
      <>
        <p>Porosity is computed directly from the NMR signal amplitudes:</p>
        <div className="ab-equation-box">
          <span className="ab-eq">ϕ = C · Σ Aᵢ</span>
        </div>
        <div className="ab-legend">
          <div><span className="ab-sym">ϕ</span> = Porosity</div>
          <div><span className="ab-sym">Aᵢ</span> = Signal amplitude</div>
          <div><span className="ab-sym">C</span> = Calibration constant</div>
        </div>
        <p>Porosity is directly proportional to the NMR signal.</p>
      </>
    ),
  },
  {
    n: 6,
    title: 'Bound vs Free Fluid',
    content: (
      <>
        <p>
          A cutoff time (typically <strong>33 ms</strong>) is used to separate fluids:
        </p>
        <div className="ab-cutoff-grid">
          <div className="ab-cutoff-card">
            <div className="ab-cutoff-cond">T₂ &lt; T<sub>cutoff</sub></div>
            <div className="ab-cutoff-name ab-bound-color">Bound Fluid Volume (BFV)</div>
            <div className="ab-cutoff-desc">Trapped in small pores — immovable</div>
          </div>
          <div className="ab-cutoff-card">
            <div className="ab-cutoff-cond">T₂ &gt; T<sub>cutoff</sub></div>
            <div className="ab-cutoff-name ab-free-color">Free Fluid Index (FFI)</div>
            <div className="ab-cutoff-desc">In large pores — can flow</div>
          </div>
        </div>
      </>
    ),
  },
  {
    n: 7,
    title: 'FFI & BFV Equations',
    content: (
      <>
        <p>The total porosity is partitioned into movable and immobile fluid components:</p>
        <div className="ab-equation-box">
          <div className="ab-eq">FFI = ϕ × ( Σ Aᵢ [T₂ &gt; T<sub>cutoff</sub>] / Σ Aᵢ )</div>
        </div>
        <div className="ab-equation-box" style={{ marginTop: '0.75rem' }}>
          <div className="ab-eq">BFV = ϕ × ( Σ Aᵢ [T₂ &lt; T<sub>cutoff</sub>] / Σ Aᵢ )</div>
        </div>
      </>
    ),
  },
  {
    n: 8,
    title: 'Permeability — SDR Model',
    content: (
      <>
        <p>Permeability is estimated using the Schlumberger-Doll Research (SDR) model:</p>
        <div className="ab-equation-box">
          <span className="ab-eq">k = 4 · ϕ⁴ · T₂<sub>LM</sub>²</span>
        </div>
        <div className="ab-legend">
          <div><span className="ab-sym">k</span> = Permeability (mD)</div>
          <div><span className="ab-sym">T₂<sub>LM</sub></span> = Logarithmic mean of T₂</div>
          <div><span className="ab-sym">ϕ</span> = Porosity</div>
        </div>
        <p>Higher T₂ and porosity values indicate better permeability.</p>
      </>
    ),
  },
  {
    n: 9,
    title: 'Interpretation of Results',
    content: (
      <>
        <p>NMR results help evaluate reservoir quality:</p>
        <div className="ab-interp-grid">
          <div className="ab-interp-item"><span className="ab-interp-icon ab-good">↑</span><div><strong>High FFI</strong> — good production potential</div></div>
          <div className="ab-interp-item"><span className="ab-interp-icon ab-warn">↑</span><div><strong>High BFV</strong> — more trapped fluids</div></div>
          <div className="ab-interp-item"><span className="ab-interp-icon ab-good">↑</span><div><strong>Long T₂</strong> — larger pores, better flow</div></div>
          <div className="ab-interp-item"><span className="ab-interp-icon ab-good">↑</span><div><strong>High k</strong> — higher permeability</div></div>
        </div>
        <p>These parameters guide reservoir engineering decisions.</p>
      </>
    ),
  },
]

export default function AboutPage() {
  const navigate = useNavigate()

  return (
    <div className="ab-root">
      <nav className="ab-nav">
        <span className="ab-nav-logo" onClick={() => navigate('/')}>NMR Analyzer</span>
        <div className="ab-nav-links">
          <button className="ab-nav-link" onClick={() => navigate('/')}>Home</button>
          <button className="ab-nav-link ab-nav-active">About NMR</button>
          <button className="ab-nav-btn" onClick={() => navigate('/analysis')}>Start Analysis</button>
        </div>
      </nav>

      <header className="ab-hero">
        <div className="ab-hero-badge">Theory &amp; Principles</div>
        <h1 className="ab-hero-title">About NMR Well Logging</h1>
        <p className="ab-hero-sub">
          A concise guide to the physics, equations, and interpretation behind NMR log analysis.
        </p>
      </header>

      <main className="ab-main">
        <div className="ab-container">
          {sections.map((s) => (
            <div className="ab-section-card" key={s.n}>
              <div className="ab-section-body">
                <h2 className="ab-section-title">{s.title}</h2>
                <div className="ab-section-content">{s.content}</div>
              </div>
            </div>
          ))}

          <div className="ab-key-insight">
            <div className="ab-insight-icon">💡</div>
            <div>
              <div className="ab-insight-label">Key Insight</div>
              <p className="ab-insight-text">
                NMR directly measures fluids in the pore space, making it one of the most reliable
                tools for reservoir evaluation.
              </p>
            </div>
          </div>
        </div>
      </main>

      <footer className="ab-footer">
        <div className="ab-container">
          <span>NMR Well Log Analyzer</span>
          <div className="ab-footer-credit">
            Department of Chemical and Petroleum Engineering &mdash; Sultan Qaboos University
          </div>
        </div>
      </footer>
    </div>
  )
}
