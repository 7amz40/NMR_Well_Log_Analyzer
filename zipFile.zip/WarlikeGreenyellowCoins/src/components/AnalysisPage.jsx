import { useState, useCallback, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import * as XLSX from 'xlsx'
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend,
} from 'recharts'
import html2canvas from 'html2canvas'
import './AnalysisPage.css'

function processNMR(rawRows, t2Cutoff, calibrationFactor) {
  // Group rows by depth
  const depthMap = new Map()
  for (const r of rawRows) {
    if (!depthMap.has(r.Depth)) depthMap.set(r.Depth, [])
    depthMap.get(r.Depth).push(r)
  }

  return Array.from(depthMap.entries()).map(([depth, bins]) => {
    const sumAmp = bins.reduce((s, b) => s + (b.Amplitude || 0), 0)
    const sumAmpFree = bins
      .filter(b => b.T2 > t2Cutoff)
      .reduce((s, b) => s + (b.Amplitude || 0), 0)

    const phi = calibrationFactor * sumAmp
    const ffiAbs = calibrationFactor * sumAmpFree
    const bvAbs = phi - ffiAbs
    const ffi = phi > 0 ? (ffiAbs / phi) * 100 : 0
    const bfv = phi > 0 ? (bvAbs / phi) * 100 : 0

    // Log-mean T2 weighted by amplitude
    const sumAmpLogT2 = bins.reduce((s, b) => s + (b.Amplitude || 0) * Math.log(b.T2 > 0 ? b.T2 : 1), 0)
    const t2LogMean = sumAmp > 0 ? Math.exp(sumAmpLogT2 / sumAmp) : 0

    const k = 4 * Math.pow(t2LogMean, 2) * Math.pow(phi, 4)
    const rqi = phi > 0 ? Math.sqrt(k / phi) : 0

    return {
      depth,
      T2: +t2LogMean.toFixed(4),
      Amplitude: +sumAmp.toFixed(4),
      phi: +phi.toFixed(4),
      ffi: +ffi.toFixed(4),
      bfv: +bfv.toFixed(4),
      k: +k.toFixed(4),
      rqi: +rqi.toFixed(4),
    }
  })
}

const CHART_CONFIGS = [
  { key: 'phi',  label: 'Porosity (ϕ)',                color: '#63b3ed', unit: 'fraction' },
  { key: 'ffi',  label: 'Free Fluid Index (FFI)',       color: '#68d391', unit: '%' },
  { key: 'bfv',  label: 'Bound Fluid Volume (BFV)',     color: '#f6ad55', unit: '%' },
  { key: 'k',    label: 'Permeability (k)',              color: '#fc8181', unit: 'mD' },
  { key: 'rqi',  label: 'Reservoir Quality Index (RQI)', color: '#b794f4', unit: '' },
]


function SingleChart({ cfg, chartData }) {
  const cardRef = useRef(null)

  const downloadChart = async () => {
    if (!cardRef.current) return
    const canvas = await html2canvas(cardRef.current, {
      backgroundColor: '#111827',
      scale: 2,
    })
    const link = document.createElement('a')
    link.download = `nmr_${cfg.key}.png`
    link.href = canvas.toDataURL('image/png')
    link.click()
  }

  return (
    <div className="ap-chart-card" ref={cardRef}>
      <div className="ap-chart-card-header">
        <div className="ap-chart-title" style={{ color: cfg.color }}>{cfg.label}</div>
        <button className="ap-chart-dl-btn" onClick={downloadChart} title={`Download ${cfg.label}`}>
          <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
            <polyline points="7 10 12 15 17 10"/>
            <line x1="12" y1="15" x2="12" y2="3"/>
          </svg>
        </button>
      </div>
      <ResponsiveContainer width="100%" height={600}>
        <LineChart
          data={chartData}
          layout="vertical"
          margin={{ top: 8, right: 24, bottom: 8, left: 8 }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
          <YAxis
            dataKey="depth"
            type="number"
            domain={[4000, 'auto']}
            tick={{ fill: '#718096', fontSize: 11 }}
            width={52}
            label={{ value: 'Depth (m)', angle: -90, position: 'insideLeft', fill: '#718096', fontSize: 11, offset: 10 }}
          />
          <XAxis
            dataKey={cfg.key}
            type="number"
            domain={['auto', 'auto']}
            orientation="top"
            tick={{ fill: '#718096', fontSize: 11 }}
            label={{ value: cfg.unit, position: 'insideTop', offset: -2, fill: '#718096', fontSize: 11 }}
          />
          <Tooltip
            contentStyle={{ background: '#111827', border: '1px solid rgba(99,179,237,0.2)', borderRadius: 8, fontSize: 12 }}
            formatter={(v) => [+v.toFixed(4), cfg.label]}
            labelFormatter={(v) => `Depth: ${v} m`}
          />
          <Line
            type="monotone"
            dataKey={cfg.key}
            stroke={cfg.color}
            strokeWidth={2}
            dot={false}
            isAnimationActive={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}

export default function AnalysisPage() {
  const navigate = useNavigate()
  const [rows, setRows] = useState(null)
  const [results, setResults] = useState(null)
  const [t2Cutoff, setT2Cutoff] = useState(33)
  const [calibrationFactor, setCalibrationFactor] = useState(0.8)
  const [error, setError] = useState('')
  const [fileName, setFileName] = useState('')
  const [dragging, setDragging] = useState(false)

  const parseFile = (file) => {
    setError('')
    setFileName(file.name)
    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const wb = XLSX.read(e.target.result, { type: 'array' })
        const ws = wb.Sheets[wb.SheetNames[0]]
        const json = XLSX.utils.sheet_to_json(ws, { defval: '' })

        if (!json.length) { setError('The file is empty.'); return }

        const keys = Object.keys(json[0])
        const depthKey = keys.find(k => /depth/i.test(k))
        const t2Key = keys.find(k => /t2/i.test(k))
        const ampKey = keys.find(k => /amp/i.test(k))

        if (!depthKey || !t2Key) {
          setError('Could not find "Depth" and "T2" columns. Please check your file format.')
          return
        }

        const parsed = json
          .map(r => ({
            Depth: parseFloat(r[depthKey]),
            T2: parseFloat(r[t2Key]),
            Amplitude: ampKey ? parseFloat(r[ampKey]) : NaN,
          }))
          .filter(r => !isNaN(r.Depth) && !isNaN(r.T2))

        if (!parsed.length) { setError('No valid numeric rows found.'); return }

        setRows(parsed)
        setResults(processNMR(parsed, t2Cutoff, calibrationFactor))
      } catch {
        setError('Failed to parse file. Make sure it is a valid Excel or CSV file.')
      }
    }
    reader.readAsArrayBuffer(file)
  }

  const onFileChange = (e) => {
    const file = e.target.files?.[0]
    if (file) parseFile(file)
  }

  const onDrop = useCallback((e) => {
    e.preventDefault()
    setDragging(false)
    const file = e.dataTransfer.files?.[0]
    if (file) parseFile(file)
  }, [t2Cutoff])

  const onDragOver = (e) => { e.preventDefault(); setDragging(true) }
  const onDragLeave = () => setDragging(false)

  const recalculate = () => {
    if (rows) setResults(processNMR(rows, t2Cutoff, calibrationFactor))
  }

  const chartData = results
    ? [...results].sort((a, b) => a.depth - b.depth)
    : []

  const downloadExcel = () => {
    const exportData = chartData.map(r => ({
      'Depth (m)': r.depth,
      'Porosity ϕ': r.phi,
      'FFI (%)': r.ffi,
      'BFV (%)': r.bfv,
      'Permeability k (mD)': r.k,
      'RQI': r.rqi,
    }))
    const ws = XLSX.utils.json_to_sheet(exportData)
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, 'NMR Results')
    XLSX.writeFile(wb, 'nmr_results.xlsx')
  }

  return (
    <div className="ap-root">
      <nav className="ap-nav">
        <button className="ap-back-btn" onClick={() => navigate('/')}>
          ← Home
        </button>
        <span className="ap-nav-title">NMR Well Log Analyzer</span>
        <span className="ap-nav-right">Analysis</span>
      </nav>

      <div className="ap-body">
        <aside className="ap-sidebar">
          <div className="ap-sidebar-section">
            <a
              className="ap-sample-btn"
              href="/NMR_sample_data.xlsx"
              download="NMR_sample_data.xlsx"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                <polyline points="7 10 12 15 17 10"/>
                <line x1="12" y1="15" x2="12" y2="3"/>
              </svg>
              Download Sample Data
            </a>
            <div className="ap-sidebar-label" style={{ marginTop: '1rem' }}>Upload Data</div>

            <div
              className={`ap-dropzone ${dragging ? 'ap-dropzone--active' : ''}`}
              onDrop={onDrop}
              onDragOver={onDragOver}
              onDragLeave={onDragLeave}
              onClick={() => document.getElementById('file-input').click()}
            >
              <div className="ap-dropzone-icon">📂</div>
              <div className="ap-dropzone-text">
                {fileName ? fileName : 'Drop Excel / CSV file here'}
              </div>
              <div className="ap-dropzone-sub">or click to browse</div>
              <input
                id="file-input"
                type="file"
                accept=".xlsx,.xls,.csv"
                style={{ display: 'none' }}
                onChange={onFileChange}
              />
            </div>

            {error && <div className="ap-error">{error}</div>}

            <div className="ap-format-hint">
              <div className="ap-hint-title">Expected columns:</div>
              <div className="ap-hint-cols">
                <span>Depth</span><span>T2</span><span>Amplitude</span>
              </div>
            </div>
          </div>

          <div className="ap-sidebar-section">
            <div className="ap-sidebar-label">Settings</div>
            <label className="ap-setting-label">
              Calibration Factor (C)
              <input
                className="ap-setting-input"
                type="number"
                value={calibrationFactor}
                step={0.01}
                min={0}
                onChange={e => setCalibrationFactor(Math.round(Number(e.target.value) * 100) / 100)}
              />
            </label>
            <div className="ap-setting-hint">ϕ = C × Amplitude</div>
            <label className="ap-setting-label" style={{ marginTop: '0.85rem' }}>
              T₂ Cutoff (ms)
              <input
                className="ap-setting-input"
                type="number"
                value={t2Cutoff}
                min={1}
                max={1000}
                onChange={e => setT2Cutoff(Number(e.target.value))}
              />
            </label>
            <button
              className="ap-recalc-btn"
              onClick={recalculate}
              disabled={!rows}
            >
              Recalculate
            </button>
          </div>

          {results && (
            <div className="ap-sidebar-section">
              <div className="ap-sidebar-label">Summary</div>
              <div className="ap-summary-grid">
                {[
                  { label: 'Rows', value: results.length },
                  { label: 'Avg ϕ',   value: (results.reduce((s,r)=>s+r.phi,0)/results.length).toFixed(3) },
                  { label: 'Avg FFI', value: (results.reduce((s,r)=>s+r.ffi,0)/results.length).toFixed(2) + '%' },
                  { label: 'Avg BFV', value: (results.reduce((s,r)=>s+r.bfv,0)/results.length).toFixed(2) + '%' },
                  { label: 'Avg k',   value: (results.reduce((s,r)=>s+r.k,0)/results.length).toFixed(2) },
                  { label: 'Avg RQI', value: (results.reduce((s,r)=>s+r.rqi,0)/results.length).toFixed(3) },
                ].map(s => (
                  <div className="ap-summary-item" key={s.label}>
                    <div className="ap-summary-val">{s.value}</div>
                    <div className="ap-summary-key">{s.label}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </aside>

        <main className="ap-main">
          {!results ? (
            <div className="ap-empty">
              <div className="ap-empty-icon">🪨</div>
              <div className="ap-empty-title">No data loaded</div>
              <div className="ap-empty-sub">Upload an Excel or CSV file to begin analysis</div>
            </div>
          ) : (
            <>
              <div className="ap-results-header">
                <h2 className="ap-results-title">Reservoir Property Logs</h2>
                <span className="ap-results-count">{results.length} depth points</span>
              </div>

              <div className="ap-charts-grid">
                {/* Porosity & Permeability side by side */}
                <div className="ap-charts-pair">
                  {CHART_CONFIGS.filter(c => c.key === 'phi' || c.key === 'k').map(cfg => (
                    <SingleChart key={cfg.key} cfg={cfg} chartData={chartData} />
                  ))}
                </div>
                {/* FFI & BFV side by side */}
                <div className="ap-charts-pair">
                  {CHART_CONFIGS.filter(c => c.key === 'ffi' || c.key === 'bfv').map(cfg => (
                    <SingleChart key={cfg.key} cfg={cfg} chartData={chartData} />
                  ))}
                </div>
                {/* RQI — same width as paired charts */}
                <div className="ap-charts-pair">
                  {CHART_CONFIGS.filter(c => c.key === 'rqi').map(cfg => (
                    <SingleChart key={cfg.key} cfg={cfg} chartData={chartData} />
                  ))}
                </div>
              </div>

              <div className="ap-table-section">
                <div className="ap-table-header">
                  <h3 className="ap-table-title">Results Table</h3>
                  <button className="ap-chart-dl-btn" onClick={downloadExcel} title="Download Results as Excel">
                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                      <polyline points="7 10 12 15 17 10"/>
                      <line x1="12" y1="15" x2="12" y2="3"/>
                    </svg>
                  </button>
                </div>
                <div className="ap-table-wrap">
                  <table className="ap-table">
                    <thead>
                      <tr>
                        <th>Depth (m)</th>
                        <th>Porosity ϕ</th>
                        <th>FFI (%)</th>
                        <th>BFV (%)</th>
                        <th>k (mD)</th>
                        <th>RQI</th>
                      </tr>
                    </thead>
                    <tbody>
                      {chartData.map((r, i) => (
                        <tr key={i}>
                          <td>{r.depth}</td>
                          <td>{r.phi}</td>
                          <td>{r.ffi}</td>
                          <td>{r.bfv}</td>
                          <td>{r.k}</td>
                          <td>{r.rqi}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </main>
      </div>
    </div>
  )
}
