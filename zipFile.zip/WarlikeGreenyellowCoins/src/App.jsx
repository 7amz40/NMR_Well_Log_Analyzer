import { Routes, Route } from 'react-router-dom'
import HomePage from './components/HomePage'
import AnalysisPage from './components/AnalysisPage'
import AboutPage from './components/AboutPage'
import './App.css'

function App() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/analysis" element={<AnalysisPage />} />
      <Route path="/about" element={<AboutPage />} />
    </Routes>
  )
}

export default App
